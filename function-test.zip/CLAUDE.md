# Portfolio Agent

Automated stock monitoring system that runs on Google Cloud Platform. Monitors 12 stocks during market hours using AI-powered analysis to generate buy/sell targets and email alerts.

**ALWAYS RESPOND IN ENGLISH**

## 📋 Core Working Principles

1. For maximum efficiency, whenever you need to perform multiple independent operations, invoke all relevant tools simultaneously and in parallel.
2. Before you finish, please verify your solution
3. Do what has been asked; nothing more, nothing less.
4. NEVER create files unless they're absolutely necessary for achieving your goal.
5. ALWAYS prefer editing an existing file to creating a new one.
6. NEVER proactively create documentation files (*.md) or README files. Only create documentation files if explicitly requested by the User.
7. Portfolio configuration is in `main.py:24-45` 
8. Update 'CLAUDE.md' and 'README.md' after making changes in 'main.py'

## 🚀 Efficient Commands

One CLI command > Multiple tool calls

    1. Pattern Search:
    - rg -n "pattern" --glob '!portfolio-env/*' instead of multiple Grep calls
    
    2. File Finding:
    - fd filename or fd .py . instead of Glob tool
    
    3. File Preview:
    - bat -n main.py for syntax-highlighted preview with line numbers
    
    4. Function Search:
    - rg -n "def portfolio_monitor" main.py for quick function location
    
    5. Log Monitoring:
    - gcloud functions logs read portfolio-monitor --region=us-central1

## 🏗️ Project Stack

- **Python 3.12** - Main runtime environment (GCP compatible)
- **Google Cloud Functions** - Serverless compute platform
- **Google Cloud Scheduler** - Automated job scheduling
- **Google Firestore** - Dynamic target storage with fallback
- **Yahoo Finance API** - Real-time stock price data
- **Claude AI (Haiku)** - Fundamental analysis and target generation
- **Gmail SMTP** - HTML email notifications
- **BeautifulSoup4** - MarketWatch web scraping
- **yfinance** - Bulk + threaded stock price fetching

## 🏛️ Architectural Principles

**"As simple as possible, but not simpler"**

- **KISS + DRY + YAGNI + Occam's Razor**: each new entity must justify its existence
- **Prior-art first**: look for existing solutions first, then write our own
- **Documentation = part of code**: architectural decisions are recorded in code and comments
- **No premature optimization**
- **100% certainty**: evaluate cascading effects before changes

## 🚨 Code Quality Standards

**All code checks are mandatory - code must be ✅ CLEAN!**
No errors. No formatting issues. No compiler warnings.

**Architectural standards:**

- Minimally sufficient patterns (don't overcomplicate)
- Decomposition: break tasks into subtasks
- Cascading effects: evaluate impact of changes

## 🎯 Main Project Features

1. **Daily Portfolio Monitoring** - Automated stock price tracking at 3 PM ET (Mon-Fri)
2. **AI-Powered Target Generation** - Monthly analysis using Claude AI for buy/sell targets
3. **Email Alert System** - HTML notifications with color-coded signals and confidence scores
4. **Market Hours Logic** - Automatic US market hours and holiday detection
5. **Fallback System** - Hardcoded targets when Firestore/AI fails

## 📁 Project Structure

```
Portfolio-Agent/
  📱 main.py                    # Cloud Functions entry points
  🧩 portfolio-env/             # Python virtual environment  
  📄 requirements.txt           # Dependencies
  🔧 .env.yaml                  # Environment variables (local only)
  🏷️ CLAUDE.md                 # This file
  📖 README.md                  # Project documentation
```

> 📖 **Core Functions**: `portfolio_monitor()` and `monthly_target_update()` in main.py

## ✅ Verification Checkpoints

**Stop and check** at these moments:

- After implementing a complete function
- Before starting a new component/module
- Before declaring "done"

Run check: `python main.py` (local) or check Cloud Functions logs

> Why: This prevents error accumulation and ensures code stability.

## 💻 Development Commands

### Local Testing

- `source portfolio-env/bin/activate` - Activate virtual environment
- `pip install -r requirements.txt` - Install dependencies
- `python main.py` - Test basic functionality
- `python test_local.py` - Test email and monitoring (if exists)

### Google Cloud Deployment

#### Secure Deployment (Recommended - with Secret Manager)
```bash
# Deploy without .env.yaml file - uses Secret Manager instead
gcloud functions deploy portfolio-monitor \
  --runtime python312 \
  --trigger-http \
  --entry-point portfolio_monitor \
  --set-env-vars GOOGLE_CLOUD_PROJECT=your-project-id

gcloud functions deploy monthly-target-update \
  --runtime python312 \
  --trigger-http \
  --entry-point monthly_target_update \
  --set-env-vars GOOGLE_CLOUD_PROJECT=your-project-id
```

#### Alternative Deployment (with environment variables)
```bash  
# Only for non-production or configuration flags
gcloud functions deploy portfolio-monitor \
  --runtime python312 \
  --trigger-http \
  --entry-point portfolio_monitor \
  --env-vars-file deployment.env.yaml
```

**IMPORTANT SECURITY NOTES:**
- ❌ NEVER use `--env-vars-file .env.yaml` in production 
- ❌ NEVER include credentials in deployment commands
- ✅ Always use Google Cloud Secret Manager for sensitive data
- ✅ Only set non-sensitive configuration via environment variables

### Monitoring

- `gcloud functions logs read portfolio-monitor --region=us-central1` - View monitoring logs  
- `gcloud functions logs read monthly-target-update --region=us-central1` - View update logs
- `gcloud scheduler jobs list --location=us-central1` - Check scheduler status

## 💻 Coding Standards

### Mandatory rules:

- Always use specific types (Python type hints recommended)
- Use constants and configuration from `main.py:24-45`
- Reuse existing components and utilities
- Always handle exceptions with fallback mechanisms
- **Meaningful names** for variables and functions
- **Early returns** to reduce nesting
- **Error handling** explicit and clear

## 📊 Implementation Standards

### Code is considered ready when:

- ✓ Local test passes without errors (`python main.py`)
- ✓ All Cloud Function deployments succeed
- ✓ Email notifications work end-to-end
- ✓ Market hours logic validated
- ✓ Function works during market hours
- ✓ Old/unused code removed
- ✓ Code is understandable to junior developer

### Testing Strategy

- Local testing with `python main.py`
- Integration tests for email/notifications
- Manual testing via Cloud Console
- Market hours validation during deployment

### **Security always**:

- Validate all external API data
- Store sensitive data in `.env.yaml` (local only)
- Use Gmail app passwords, not account passwords
- Handle all external API timeouts and errors

## 🔧 Configuration

### Environment Configuration

#### Local Development (.env.yaml)
**SECURITY NOTE**: Never commit .env.yaml with real credentials to Git!

1. Copy `.env.yaml.template` to `.env.yaml`
2. Fill in your actual credentials:

**Required:**
- `GMAIL_USER`: Gmail address for sending alerts
- `GMAIL_PASSWORD`: Gmail app password (16 characters)
- `CLAUDE_API_KEY`: Anthropic Claude API key for AI analysis

**Optional:**
- `ALERT_RECIPIENT`: Email recipient (defaults to GMAIL_USER)

**Data Collection Feature Flags:**
- `ENABLE_MW_SCRAPE`: true/false (default: true) - Enable MarketWatch scraping
- `ENABLE_YF_WEB_SCRAPE`: true/false (default: true) - Enable Yahoo web scraping
- `ENABLE_DATA_CACHE`: true/false (default: false) - Enable data caching layer
- `CACHE_DURATION_MINUTES`: integer (default: 30) - Cache expiration time

#### Production (Google Cloud)
**RECOMMENDED**: Use Google Cloud Secret Manager for production deployment

1. Store secrets in Google Cloud Secret Manager:
```bash
# Store secrets (replace with your actual values)
echo -n "your-email@gmail.com" | gcloud secrets create GMAIL_USER --data-file=-
echo -n "your-16-char-app-password" | gcloud secrets create GMAIL_PASSWORD --data-file=-  
echo -n "sk-ant-api03-your-key-here" | gcloud secrets create CLAUDE_API_KEY --data-file=-
```

2. Grant Cloud Function access to secrets:
```bash
gcloud projects add-iam-policy-binding PROJECT_ID \
    --member="serviceAccount:PROJECT_ID@appspot.gserviceaccount.com" \
    --role="roles/secretmanager.secretAccessor"
```

**Alternative**: Set environment variables in Cloud Function configuration
- Only use this for non-sensitive configuration flags
- Never use this for passwords or API keys

### Portfolio Configuration
Edit `PORTFOLIO` dictionary in `main.py:24-45` for:
- Stocks to monitor (currently 12 stocks)
- Hardcoded fallback buy/sell targets
- Position sizes for value calculations

## 🌟 Key Implementation Features

### Market Hours & Holiday Detection

- Automatic US market hours validation (9:30 AM - 4:00 PM ET)
- Built-in US holiday detection
- Functions only execute during valid market periods

### AI-Powered Analysis

- Uses Claude Haiku model for cost optimization
- Multi-source data validation with confidence scoring
- Fallback to hardcoded targets if AI/Firestore fails

## 🔧 Data Collection Optimization Features

### Smart Fallback Logic
The system now uses intelligent data source selection:

1. **Always**: Yahoo Finance API (primary source)
2. **Conditional**: MarketWatch scraping (only if API data insufficient)
3. **Conditional**: Yahoo web scraping (only if other sources failed)

Data quality thresholds automatically determine when additional sources are needed.

### Enhanced AI Analysis
Claude prompts now include:
- **Rating Distribution**: Buy/Hold/Sell breakdown with percentages
- **Data Source Transparency**: Which sources provided the data
- **Confidence Metrics**: More prominent scoring in analysis

### Optional Caching Layer
- In-memory cache with configurable expiration
- Cache key format: `{ticker}_{date}_{source_type}`
- Automatic cache validation and cleanup
- Performance optimization for repeated requests

## 🚨 Troubleshooting Guide

### Data Source Configuration Issues

**Problem**: No analyst data collected
**Solutions**:
1. Check if feature flags are correctly set in `.env.yaml`
2. Verify environment variables are loaded: `echo $ENABLE_MW_SCRAPE`
3. Test individual sources by enabling only one at a time

**Problem**: MarketWatch scraping fails
**Solutions**:
1. Set `ENABLE_MW_SCRAPE: false` to disable temporarily
2. Check for rate limiting (429 errors)
3. Verify URL accessibility manually

**Problem**: Yahoo web scraping returns no data
**Solutions**:
1. Set `ENABLE_YF_WEB_SCRAPE: false` if not needed
2. Check Yahoo Finance page structure changes
3. Monitor for anti-bot measures

### Cache-Related Issues

**Problem**: Stale data being returned
**Solutions**:
1. Reduce `CACHE_DURATION_MINUTES` value
2. Set `ENABLE_DATA_CACHE: false` to disable caching
3. Clear cache manually during testing

**Problem**: Cache not working as expected
**Solutions**:
1. Verify `ENABLE_DATA_CACHE: true` is set
2. Check cache statistics in logs
3. Ensure sufficient memory for cache storage

### Performance Optimization

**Problem**: Slow data collection
**Solutions**:
1. Enable caching: `ENABLE_DATA_CACHE: true`
2. Disable unnecessary scraping sources
3. Increase cache duration for stable data

**Problem**: Rate limiting from APIs
**Solutions**:
1. Disable web scraping sources temporarily
2. Add delays between requests
3. Use caching to reduce API calls

### Deployment Configuration

**Problem**: Feature flags not working in Cloud Functions
**Solutions**:
1. Ensure `.env.yaml` is properly configured for deployment
2. Verify environment variables are set in GCP Console
3. Check function logs for environment variable loading

**Problem**: Cache doesn't persist between function calls
**Expected Behavior**: This is normal - cache is in-memory only and resets with each cold start

**IMPORTANT:** 
- Update 'CLAUDE.md' and 'README.md' after changes in 'main.py'
- Do not push CLAUDE.md to GitHub - keep locally only

---